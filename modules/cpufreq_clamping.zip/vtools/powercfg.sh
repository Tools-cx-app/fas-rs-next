#!/system/bin/sh

case $1 in
	"powersave" | "balance" | "performance")
		echo 1 > /sys/module/cpufreq_clamping/parameters/enable 
		echo "$1" > /data/cur_powermode.txt;;

	"fast")
		echo 0 > /sys/module/cpufreq_clamping/parameters/enable 
		echo "$1" > /data/cur_powermode.txt;;

	"init")
		/data/powercfg.sh $(cat /data/cur_powermode.txt) ;;
	
	*) echo "Failed to apply unknown action '$1'." ;;
esac
