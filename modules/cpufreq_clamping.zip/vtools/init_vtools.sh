BASEDIR="$(dirname $(readlink -f "$0"))"

source $BASEDIR/gen_json.sh $1
echo "$json" >/data/powercfg.json

cp -af $BASEDIR/powercfg.sh /data/powercfg.sh
chmod 755 /data/powercfg.sh

cp -af $BASEDIR/module_switch.ini /data/module_switch.ini
chmod 644 /data/module_switch.ini

cur_powermode="/data/cur_powermode.txt"
if [ ! -f "$cur_powermode" ]; then
	touch "$cur_powermode"
	echo "balance" > "$cur_powermode"
fi