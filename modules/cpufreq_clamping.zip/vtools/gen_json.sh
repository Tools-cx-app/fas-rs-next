propPath=$1
version=$(cat $propPath | grep "version=" | cut -d "=" -f2)
versionCode=$(cat $propPath | grep "versionCode=" | cut -d "=" -f2)

json=$(
	cat <<EOF
{
	"name": "cpufreq_clamping",
	"author": "ztc1997",
	"version": "$version",
	"versionCode": ${versionCode},
	"features": {
		"strict": false,
		"pedestal": false
	},
	"module": "cpufreq_clamping",
	"state": "/data/cur_powermode.txt",
	"entry": "/data/powercfg.sh"
}
EOF
)