MODDIR=${0%/*}
EXTENSIONS=/data/adb/fas_rs/extensions

wait_until_login() {
    # in case of /data encryption is disabled
    while [ "$(getprop sys.boot_completed)" != "1" ]; do
        sleep 1
    done

    # in case of the user unlocked the screen
    until [ -d "/data/data/android" ]; do
        sleep 1
    done
}
wait_until_login

if [ "$(ps |grep fas-rs-next|echo '$?')" != "0" ]; then
	sh $MODDIR/vtools/init_vtools.sh $(realpath $MODDIR/module.prop)
fi

sleep 90

kernel_version=$(uname -r)
major_version=$(echo "$kernel_version" | awk -F '.' '{print $1 "." $2}')

if [ "$major_version" == "5.10" ]; then
    echo "正在加载 5.10 版本模块"
    module_path="$MODDIR/5.10/cpufreq_clamping.ko"
elif [ "$major_version" == "5.15" ]; then
    echo "正在加载 5.15 版本模块"
    module_path="$MODDIR/5.15/cpufreq_clamping.ko"
else
    echo "内核版本不匹配: $major_version. 仅支持 5.10 和 5.15"
    exit 1
fi

insmod "$module_path" 2>&1
if [ $? -ne 0 ]; then
    echo "$major_version模块载入失败"
    dmesg | grep -i cpufreq_clamping | tail -n 20
    exit 1
fi

sh $MODDIR/apply_config.sh

if [ "$(ps |grep fas-rs-next|echo '$?')" != "0" ]; then
	until [ -d $EXTENSIONS ]; do
    	sleep 1
    done
    
    cp -f $MODDIR/extension/cpufreq_clamping.lua $EXTENSIONS/cpufreq_clamping.lua
fi
