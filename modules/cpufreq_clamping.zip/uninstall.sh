rm /data/cpufreq_clamping.conf
rm /data/powercfg.json
rm /data/powercfg.sh
rm /data/module_switch.ini
rm /data/cur_powermode.txt
