API_VERSION = 0

function start_fas()
    -- log_info("[cpufreq_clamping] fas-rs start_fas, disable cpufreq_clamping")
    io.open("/sys/module/cpufreq_clamping/parameters/enable", "w"):write("0")
end

function stop_fas()
    -- log_info("[cpufreq_clamping] fas-rs stop_fas, enable cpufreq_clamping")
    io.open("/sys/module/cpufreq_clamping/parameters/enable", "w"):write("1")
end

function load_fas(pid, pkg)
    -- log_info("[cpufreq_clamping] fas-rs load_fas, disable cpufreq_clamping")
    io.open("/sys/module/cpufreq_clamping/parameters/enable", "w"):write("0")
end

function unload_fas(pid, pkg)
    -- log_info("[cpufreq_clamping] fas-rs unload_fas, enable cpufreq_clamping")
    io.open("/sys/module/cpufreq_clamping/parameters/enable", "w"):write("1")
end
