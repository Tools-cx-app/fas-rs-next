set_perm_recursive $MODPATH 0 0 0755 0644
RECREAT_CPUFREQ_CLAMPING_CONF=0
CPUFREQ_CLAMPING_CONF="/data/cpufreq_clamping.conf"
EXTENSIONS=/data/adb/fas_rs/extensions
DEFAULT_CPUFREQ_CLAMPING_CONF=$(cat <<EOF
interval_ms=40
boost_app_switch_ms=150
#cluster0
baseline_freq=1700
margin=300
boost_baseline_freq=2000
max_freq=9999
#cluster1
baseline_freq=1600
margin=300
boost_baseline_freq=2000
max_freq=9999
#cluster2
baseline_freq=1600
margin=300
boost_baseline_freq=2500
max_freq=9999
EOF
)

kernel_version=$(uname -r)
major_version=$(echo "$kernel_version" | awk -F '.' '{print $1 "." $2}')

echo '准备安装模块，模块安装后立即开始生效'
echo '之后开机90秒后开始生效'
echo '===================='
echo '3秒后生效……'
sleep 1
echo '2秒后生效……'
sleep 1
echo '1秒后生效……'
sleep 1

# 检查内核版本并加载对应模块
if [ "$major_version" == "5.10" ]; then
    echo "正在加载 5.10 版本模块"
    module_path="$MODPATH/5.10/cpufreq_clamping.ko"
elif [ "$major_version" == "5.15" ]; then
    echo "正在加载 5.15 版本模块"
    module_path="$MODPATH/5.15/cpufreq_clamping.ko"
else
    echo "内核版本不匹配: $major_version. 仅支持 5.10 和 5.15"
    exit 1
fi

# 卸载旧模块并加载新模块
rmmod cpufreq_clamping 2>/dev/null
insmod "$module_path" 2>&1
if [ $? -ne 0 ]; then
    echo "$major_version模块载入失败"
    dmesg | grep -i cpufreq_clamping | tail -n 20
    exit 1
fi

creat_conf() {
  if [[ ! -f "$CPUFREQ_CLAMPING_CONF" ]]; then
      echo "正在创建配置文件"
      echo "$DEFAULT_CPUFREQ_CLAMPING_CONF" > "$CPUFREQ_CLAMPING_CONF"
      echo "/data/cpufreq_clamping.conf 创建成功"
  else
      echo "/data/cpufreq_clamping.conf 已存在，跳过"
  fi
}

recreat_conf() {
  echo "配置文件有更新，正在重新创建"
  rm "$CPUFREQ_CLAMPING_CONF"
  echo "$DEFAULT_CPUFREQ_CLAMPING_CONF" > "$CPUFREQ_CLAMPING_CONF"
  if [[ -f "$CPUFREQ_CLAMPING_CONF" ]]; then
      echo "/data/cpufreq_clamping.conf 创建成功"
  else
      echo "/data/cpufreq_clamping.conf 创建失败"
  fi
}

[[ $RECREAT_CPUFREQ_CLAMPING_CONF -eq 1 ]] && recreat_conf || creat_conf

sh $MODPATH/apply_config.sh

WEBROOT_PATH="/data/adb/modules/cpufreq_clamping/webroot"

if [ -f "$WEBROOT_PATH/index.html" ]; then
    rm -rf $WEBROOT_PATH/*
    cp -r $MODPATH/webroot/* $WEBROOT_PATH/

    echo "WEBUI 更新完毕，请结束原 WEBUI 进程后使用"
else
    echo "WEBUI 目录不存在，终止替换，WEBUI 重启后生效"
fi


if [ -d $EXTENSIONS ]; then
    cp -f $MODPATH/extension/cpufreq_clamping.lua $EXTENSIONS/cpufreq_clamping.lua
    echo "fas-rs 已运行，安装 fas-rs 扩展"
else
	sh $MODPATH/vtools/init_vtools.sh $(realpath $MODPATH/module.prop)
    echo "fas-rs 未运行，安装 scene 接口"
fi
