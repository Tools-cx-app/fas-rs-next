CONFIG_FILE="/data/cpufreq_clamping.conf"
SYSFS_PATH="/sys/module/cpufreq_clamping/parameters"

interval_ms=$(sed -n 's/^interval_ms=//p' "$CONFIG_FILE")
echo "$interval_ms" > "$SYSFS_PATH/interval_ms"

boost_app_switch_ms=$(sed -n 's/^boost_app_switch_ms=//p' "$CONFIG_FILE")
echo "$boost_app_switch_ms" > "$SYSFS_PATH/boost_app_switch_ms"

# 读取 cluster 参数并写入
for cluster in 0 1 2; do
    # 提取 baseline_freq
    baseline_freq=$(sed -n "/^#cluster${cluster}$/,/^#cluster/{ 
        /baseline_freq=/ {
            s/baseline_freq=//p
        }
    }" "$CONFIG_FILE" | head -n 1)

    # 提取 margin
    margin=$(sed -n "/^#cluster${cluster}$/,/^#cluster/{ 
        /margin=/ {
            s/margin=//p
        }
    }" "$CONFIG_FILE" | head -n 1)

    # 提取 boost_baseline_freq
    boost_baseline_freq=$(sed -n "/^#cluster${cluster}$/,/^#cluster/{ 
        /boost_baseline_freq=/ {
            s/boost_baseline_freq=//p
        }
    }" "$CONFIG_FILE" | head -n 1)
    
    # 提取 max_freq
    max_freq=$(sed -n "/^#cluster${cluster}$/,/^#cluster/{ 
        /max_freq=/ {
            s/max_freq=//p
        }
    }" "$CONFIG_FILE" | head -n 1)

    # 转换并写入
    baseline_freq_khz=$((baseline_freq * 1000))
    margin_khz=$((margin * 1000))
    boost_baseline_freq_khz=$((boost_baseline_freq * 1000))
    max_freq_khz=$((max_freq * 1000))

    echo "$cluster $baseline_freq_khz" > "$SYSFS_PATH/baseline_freq"
    echo "$cluster $margin_khz" > "$SYSFS_PATH/margin"
    echo "$cluster $boost_baseline_freq_khz" > "$SYSFS_PATH/boost_baseline_freq"
    echo "$cluster $max_freq_khz" > "$SYSFS_PATH/max_freq"
done

echo "cpufreq_clamping 参数应用成功"